#!/bin/sh

# set -x

#
# Product Specification
#
export PRODUCT_NAME="pelion-bridge"
  
#
# Get our pid
#
PID=`ps -ef | grep java | grep -v grep | grep ${PRODUCT_NAME} | awk '{ print $2 }'`

#
# Check if we are running... if so... kill...
#
if [ "${PID}X" != "X" ]; then
     echo "Killing ${PRODUCT_NAME}..."
     kill -9 ${PID}
else
     echo "${PRODUCT_NAME} is not running (OK)"
fi

#
# Exit
#
exit 0
