#!/bin/sh

JACKSON_VERSION=2.9.9
MBED_VERSION=1.0.0

run_properties_editor() {
    cd ${HOME}/properties-editor
    java -cp "./target/mbed-properties-editor-${MBED_VERSION}.jar:./target/jackson-core-${JACKSON_VERSION}.jar:./target/jackson-databind-${JACKSON_VERSION}.jar:./target/jackson-annotations-${JACKSON_VERSION}.jar" com.arm.mbed.properties.editor.Main
}

main() {
   run_properties_editor $*
}

main $*
